import JSZip from 'jszip';
import type {DomainConfig, EvaluatedRecord} from '../types/business';

function escapeKotlinString(value: string): string {
  return value.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, ' ');
}

export async function downloadAndroidStudioProject(
  domain: DomainConfig,
  records: EvaluatedRecord[]
): Promise<void> {
  const zip = new JSZip();
  const rootName = `VeridianOps_Android_${domain.id}`;
  const root = zip.folder(rootName);
  if (!root) return;

  root.file(
    'settings.gradle.kts',
    `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "VeridianOps"
include(":app")
`
  );

  root.file(
    'build.gradle.kts',
    `plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
`
  );

  root.file(
    'gradle.properties',
    `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
kotlin.code.style=official
android.nonTransitiveRClass=true
`
  );

  root.file(
    'README_APK_BUILD.md',
    `# Veridian Ops — Native Android Studio Project (${domain.name})

This project implements the 4 required mobile business screens in **Kotlin + Jetpack Compose (Material 3)** for MBA Task 3, aligned with:
- **Domain:** ${domain.name}
- **Business Problem:** ${domain.businessProblem}
- **Proposed Solution:** ${domain.proposedSolution}

## Academic Integrity & Security Compliance
- Uses **synthetic, anonymised sample data only** (no personal customer data).
- Every analytical output is explicitly labelled **Sample Model Output (Synthetic Data)**.
- **Zero hardcoded API keys or credentials** in source code.

## How to Build & Install the Working APK
1. Install **Android Studio** (Koala / Ladybug or newer) with Android SDK 35.
2. Extract this ZIP and select **File > Open** -> choose the \`${rootName}\` folder.
3. Wait for Gradle Sync to finish (first sync downloads Compose dependencies).
4. **Run on Emulator or Physical Android Phone**:
   - Connect your Android phone via USB (with **Developer Options > USB Debugging** enabled) or start a Pixel Android Virtual Device (AVD).
   - Click the green **Run** button (Shift+F10) to install and test live.
5. **Generate the Deliverable APK File**:
   - In the top menu, click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
   - Click **locate** in the notification toast (usually \`app/build/outputs/apk/debug/app-debug.apk\`).
   - Copy \`app-debug.apk\` to your Android phone or upload it with your assignment deliverables.
`
  );

  const app = root.folder('app');
  if (!app) return;

  app.file(
    'build.gradle.kts',
    `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.veridian.ops"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.veridian.ops"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.1")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.navigation:navigation-compose:2.7.7")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
`
  );

  app.file('proguard-rules.pro', `# Keep rules for release builds\n`);

  const resValues = app.folder('src/main/res/values');
  resValues?.file(
    'strings.xml',
    `<resources>
    <string name="app_name">Veridian Ops</string>
</resources>
`
  );

  app.file(
    'src/main/AndroidManifest.xml',
    `<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <application
        android:allowBackup="true"
        android:label="@string/app_name"
        android:supportsRtl="true"
        android:theme="@android:style/Theme.Material.Light.NoActionBar">
        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
`
  );

  const javaBase = app.folder('src/main/java/com/veridian/ops');
  if (!javaBase) return;

  javaBase.file(
    'MainActivity.kt',
    `package com.veridian.ops

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import com.veridian.ops.ui.VeridianApp

private val VeridianLightScheme = lightColorScheme(
    primary = Color(0xFF1D4ED8),
    onPrimary = Color.White,
    surface = Color(0xFFFFFFFF),
    background = Color(0xFFF8FAFC),
    onBackground = Color(0xFF0F172A),
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFF1F5F9),
    outline = Color(0xFFE2E8F0)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = VeridianLightScheme) {
                VeridianApp()
            }
        }
    }
}
`
  );

  const sampleListKt = records
    .map(
      (r) => `        OperationalRecord(
            id = "${escapeKotlinString(r.id)}",
            code = "${escapeKotlinString(r.code)}",
            title = "${escapeKotlinString(r.title)}",
            category = "${escapeKotlinString(r.category)}",
            currentVolume = ${r.currentVolume},
            dailyDemand = ${r.dailyDemand},
            leadTimeDays = ${r.leadTimeDays},
            unitImpactUsd = ${r.unitImpactUsd},
            status = "${escapeKotlinString(r.status)}",
            notes = "${escapeKotlinString(r.notes)}"
        )`
    )
    .join(',\n');

  javaBase.file(
    'data/SampleBusinessData.kt',
    `package com.veridian.ops.data

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

enum class RiskLevel { Critical, Watchlist, Healthy }

data class OperationalRecord(
    val id: String,
    val code: String,
    val title: String,
    val category: String,
    val currentVolume: Int,
    val dailyDemand: Int,
    val leadTimeDays: Int,
    val unitImpactUsd: Double,
    val status: String = "Open",
    val notes: String = ""
) {
    val daysOfCover: Double
        get() = (currentVolume.toDouble() / max(dailyDemand, 1))

    val safetyBufferDays: Double
        get() = daysOfCover - leadTimeDays

    val riskLevel: RiskLevel
        get() = when {
            status == "Resolved" -> RiskLevel.Healthy
            safetyBufferDays <= 0.0 || daysOfCover <= 2.5 -> RiskLevel.Critical
            safetyBufferDays <= 3.0 -> RiskLevel.Watchlist
            else -> RiskLevel.Healthy
        }

    val estimatedImpactUsd: Int
        get() {
            if (status == "Resolved") return 0
            val shortfall = max(0.0, (leadTimeDays + 2) - daysOfCover)
            return (shortfall * dailyDemand * unitImpactUsd).roundToInt()
        }

    val recommendedAction: String
        get() = when {
            status == "Resolved" -> "Marked resolved in local register."
            riskLevel == RiskLevel.Critical -> {
                val qty = max(dailyDemand * (leadTimeDays + 4) - currentVolume, dailyDemand * 3)
                "Expedite replenishment of $qty units to close a %.1f-day buffer deficit.".format(abs(safetyBufferDays))
            }
            riskLevel == RiskLevel.Watchlist -> {
                val qty = max(dailyDemand * (leadTimeDays + 5) - currentVolume, dailyDemand * 2)
                "Schedule preventive order of $qty units within 24 hours."
            }
            else -> "Maintain standard replenishment cycle."
        }
}

object SampleDomainConfig {
    const val DOMAIN_NAME = "${escapeKotlinString(domain.name)}"
    const val BUSINESS_PROBLEM = "${escapeKotlinString(domain.businessProblem)}"
    const val PROPOSED_SOLUTION = "${escapeKotlinString(domain.proposedSolution)}"
    const val VOLUME_LABEL = "${escapeKotlinString(domain.volumeLabel)}"
    const val DEMAND_LABEL = "${escapeKotlinString(domain.demandLabel)}"
    const val LEAD_TIME_LABEL = "${escapeKotlinString(domain.leadTimeLabel)}"
    const val IMPACT_LABEL = "${escapeKotlinString(domain.impactLabel)}"
    val CATEGORIES = listOf(${domain.categories.map((c) => `"${escapeKotlinString(c)}"`).join(', ')})

    fun starterRecords(): List<OperationalRecord> = listOf(
${sampleListKt}
    )
}
`
  );

  javaBase.file(
    'ui/VeridianApp.kt',
    `package com.veridian.ops.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Analytics
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.EditNote
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.veridian.ops.data.OperationalRecord
import com.veridian.ops.data.SampleDomainConfig
import com.veridian.ops.ui.screens.AssessScreen
import com.veridian.ops.ui.screens.InsightsScreen
import com.veridian.ops.ui.screens.OverviewScreen
import com.veridian.ops.ui.screens.WorkspaceScreen

sealed class AppDestination(val route: String, val label: String, val icon: ImageVector) {
    data object Overview : AppDestination("overview", "Overview", Icons.Outlined.Dashboard)
    data object Assess : AppDestination("assess", "Assess", Icons.Outlined.EditNote)
    data object Insights : AppDestination("insights", "Insights", Icons.Outlined.Analytics)
    data object Workspace : AppDestination("workspace", "Workspace", Icons.Outlined.Settings)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VeridianApp() {
    val navController = rememberNavController()
    val records = remember { mutableStateListOf<OperationalRecord>().apply { addAll(SampleDomainConfig.starterRecords()) } }
    val destinations = listOf(
        AppDestination.Overview,
        AppDestination.Assess,
        AppDestination.Insights,
        AppDestination.Workspace
    )
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: AppDestination.Overview.route

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Veridian Ops") }
            )
        },
        bottomBar = {
            NavigationBar {
                destinations.forEach { dest ->
                    NavigationBarItem(
                        selected = currentRoute == dest.route,
                        onClick = {
                            navController.navigate(dest.route) {
                                popUpTo(AppDestination.Overview.route) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(dest.icon, contentDescription = dest.label) },
                        label = { Text(dest.label) }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = AppDestination.Overview.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(AppDestination.Overview.route) {
                OverviewScreen(
                    records = records,
                    onGoToAssess = { navController.navigate(AppDestination.Assess.route) },
                    onGoToInsights = { navController.navigate(AppDestination.Insights.route) }
                )
            }
            composable(AppDestination.Assess.route) {
                AssessScreen(
                    onAddRecord = { newRecord ->
                        records.add(0, newRecord)
                        navController.navigate(AppDestination.Insights.route)
                    }
                )
            }
            composable(AppDestination.Insights.route) {
                InsightsScreen(
                    records = records,
                    onToggleResolve = { id ->
                        val idx = records.indexOfFirst { it.id == id }
                        if (idx >= 0) {
                            val item = records[idx]
                            records[idx] = item.copy(
                                status = if (item.status == "Resolved") "Open" else "Resolved"
                            )
                        }
                    }
                )
            }
            composable(AppDestination.Workspace.route) {
                WorkspaceScreen(
                    recordCount = records.size,
                    onResetSample = {
                        records.clear()
                        records.addAll(SampleDomainConfig.starterRecords())
                    }
                )
            }
        }
    }
}
`
  );

  javaBase.file(
    'ui/screens/OverviewScreen.kt',
    `package com.veridian.ops.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.veridian.ops.data.OperationalRecord
import com.veridian.ops.data.RiskLevel
import com.veridian.ops.data.SampleDomainConfig

@Composable
fun OverviewScreen(
    records: List<OperationalRecord>,
    onGoToAssess: () -> Unit,
    onGoToInsights: () -> Unit
) {
    val openCount = records.count { it.status == "Open" }
    val criticalCount = records.count { it.riskLevel == RiskLevel.Critical }
    val exposure = records.sumOf { it.estimatedImpactUsd }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "Synthetic Dataset · Sample Operational Preview",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = SampleDomainConfig.DOMAIN_NAME,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = SampleDomainConfig.BUSINESS_PROBLEM,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                KpiCard("Open Cases", "$openCount", Modifier.weight(1f))
                KpiCard("Critical Risk", "$criticalCount", Modifier.weight(1f))
                KpiCard("Est. Exposure", "$$exposure", Modifier.weight(1f))
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                Button(onClick = onGoToAssess, modifier = Modifier.weight(1f)) {
                    Text("New Assessment")
                }
                OutlinedButton(onClick = onGoToInsights, modifier = Modifier.weight(1f)) {
                    Text("View Insights")
                }
            }
        }

        item {
            Text(
                text = "Priority Queue",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
        }

        items(records, key = { it.id }) { record ->
            OutlinedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("\${record.code} · \${record.category} · \${record.riskLevel}", style = MaterialTheme.typography.labelMedium)
                    Text(record.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Text(
                        text = "%.1f days cover · Impact $%d".format(record.daysOfCover, record.estimatedImpactUsd),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}

@Composable
private fun KpiCard(label: String, value: String, modifier: Modifier = Modifier) {
    ElevatedCard(modifier = modifier) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
    }
}
`
  );

  javaBase.file(
    'ui/screens/AssessScreen.kt',
    `package com.veridian.ops.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.veridian.ops.data.OperationalRecord
import com.veridian.ops.data.SampleDomainConfig

@Composable
fun AssessScreen(onAddRecord: (OperationalRecord) -> Unit) {
    var code by remember { mutableStateOf("ITEM-901") }
    var title by remember { mutableStateOf("") }
    var volumeText by remember { mutableStateOf("90") }
    var demandText by remember { mutableStateOf("25") }
    var leadTimeText by remember { mutableStateOf("4") }
    var impactText by remember { mutableStateOf("15") }
    var selectedCategory by remember { mutableStateOf(SampleDomainConfig.CATEGORIES.first()) }
    var notes by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Operational Assessment", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(
            "Enter synthetic or anonymised unit metrics. Calculations run locally on device and produce clearly labelled sample recommendations.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        OutlinedTextField(value = code, onValueChange = { code = it }, label = { Text("Reference Code") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Item / Operation Name") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(
            value = volumeText,
            onValueChange = { volumeText = it },
            label = { Text(SampleDomainConfig.VOLUME_LABEL) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = demandText,
            onValueChange = { demandText = it },
            label = { Text(SampleDomainConfig.DEMAND_LABEL) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = leadTimeText,
            onValueChange = { leadTimeText = it },
            label = { Text(SampleDomainConfig.LEAD_TIME_LABEL) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = impactText,
            onValueChange = { impactText = it },
            label = { Text(SampleDomainConfig.IMPACT_LABEL) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Operational Context Notes") }, modifier = Modifier.fillMaxWidth())

        Button(
            onClick = {
                val safeTitle = title.ifBlank { "Sample Operation Item" }
                onAddRecord(
                    OperationalRecord(
                        id = "rec-\${System.currentTimeMillis()}",
                        code = code.ifBlank { "REC-01" },
                        title = safeTitle,
                        category = selectedCategory,
                        currentVolume = volumeText.toIntOrNull() ?: 80,
                        dailyDemand = (demandText.toIntOrNull() ?: 20).coerceAtLeast(1),
                        leadTimeDays = leadTimeText.toIntOrNull() ?: 4,
                        unitImpactUsd = impactText.toDoubleOrNull() ?: 10.0,
                        notes = notes
                    )
                )
            },
            modifier = Modifier.fillMaxWidth().height(48.dp)
        ) {
            Text("Run Sample Decision Model")
        }
    }
}
`
  );

  javaBase.file(
    'ui/screens/InsightsScreen.kt',
    `package com.veridian.ops.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.veridian.ops.data.OperationalRecord
import com.veridian.ops.data.RiskLevel

@Composable
fun InsightsScreen(
    records: List<OperationalRecord>,
    onToggleResolve: (String) -> Unit
) {
    var filter by remember { mutableStateOf("All") }
    val filtered = when (filter) {
        "Critical" -> records.filter { it.riskLevel == RiskLevel.Critical }
        "Watchlist" -> records.filter { it.riskLevel == RiskLevel.Watchlist }
        else -> records
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Sample Model Output · Synthetic Data Only", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            Text("Decision Insights", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("All", "Critical", "Watchlist").forEach { tab ->
                    FilterChip(selected = filter == tab, onClick = { filter = tab }, label = { Text(tab) })
                }
            }
        }

        items(filtered, key = { it.id }) { item ->
            OutlinedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("\${item.code} · \${item.riskLevel} · \${item.status}", style = MaterialTheme.typography.labelMedium)
                    Text(item.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text("Sample Recommendation: \${item.recommendedAction}", style = MaterialTheme.typography.bodyMedium)
                    Text(
                        "Cover: %.1f days · Buffer: %.1f days · Exposure: $%d".format(
                            item.daysOfCover,
                            item.safetyBufferDays,
                            item.estimatedImpactUsd
                        ),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedButton(onClick = { onToggleResolve(item.id) }) {
                        Text(if (item.status == "Resolved") "Reopen Case" else "Mark Resolved")
                    }
                }
            }
        }
    }
}
`
  );

  javaBase.file(
    'ui/screens/WorkspaceScreen.kt',
    `package com.veridian.ops.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.veridian.ops.data.SampleDomainConfig

@Composable
fun WorkspaceScreen(
    recordCount: Int,
    onResetSample: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Workspace & Academic Integrity", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        OutlinedCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Aligned Domain: \${SampleDomainConfig.DOMAIN_NAME}", fontWeight = FontWeight.SemiBold)
                Text("Proposed Solution: \${SampleDomainConfig.PROPOSED_SOLUTION}", style = MaterialTheme.typography.bodySmall)
                Text("Active Local Synthetic Records: $recordCount", style = MaterialTheme.typography.bodySmall)
            }
        }
        OutlinedCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Data Ethics & Security Notice", fontWeight = FontWeight.SemiBold)
                Text(
                    "All data shown in this application is synthetic and anonymised. No real customer PII, enterprise databases, or hardcoded API keys are stored or transmitted.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
        Button(onClick = onResetSample, modifier = Modifier.fillMaxWidth().height(48.dp)) {
            Text("Reset to Starter Synthetic Dataset")
        }
    }
}
`
  );

  const docs = zip.folder(`${rootName}/Deliverables_Docs`);
  if (docs) {
    docs.file(
      '01_Functionality_Explanation.md',
      `# Task 3 — Main Functionality Explanation (${domain.name})

## 1. Alignment with Tasks 1 & 2
- **Selected Business Domain:** ${domain.name}
- **Business Problem (Task 1):** ${domain.businessProblem}
- **Proposed Solution (Task 2):** ${domain.proposedSolution}

## 2. Four Core Screens
1. **Overview (Home Dashboard):** Displays domain context, 4 operational KPIs (Open Cases, Critical Attention, Average Cover Window, Projected Risk Exposure), and a prioritized action queue.
2. **Assess (Input & Problem-Solver):** Captures ${domain.volumeLabel}, ${domain.demandLabel}, ${domain.leadTimeLabel}, ${domain.impactLabel}, priority tier, and notes, with instant sample model preview.
3. **Insights (Recommendations & Analytics):** Visualizes category risk exposure, filters cases by severity (*Critical*, *Watchlist*, *Healthy*, *Resolved*), displays clearly labelled **Sample Recommendations**, and lets managers resolve or edit cases.
4. **Workspace (Settings & Integrity):** Switches business domains, resets/exports synthetic datasets, and houses academic integrity disclosures.

## 3. Data Flow, Sample Labelling & Security
- All ${records.length} active records are **synthetic and anonymised**.
- Calculations run deterministically on-device (Days of Cover = Volume / Daily Demand; Safety Buffer = Cover - Lead Time).
- All outputs are explicitly labelled as **Sample Model Output**.
- **Zero API keys, OAuth secrets, or real PII** are stored in source code or builds.
`
    );

    docs.file(
      '02_Demo_Video_Script_2to3Min.md',
      `# 2–3 Minute Demo Video Walkthrough Script (${domain.name})

- **0:00 – 0:30 | Context & Screen 1 (Overview):**
  "This is Veridian Ops, built for ${domain.name}. In Tasks 1 and 2, we identified this problem: ${domain.businessProblem} On the Overview screen, you can see the active KPIs and priority queue generated from our synthetic dataset."
- **0:30 – 1:15 | Live Input on Screen 2 (Assess):**
  "Moving to the Assess tab, a frontline manager enters operational values or loads a test scenario. Notice the live Sample Model Preview updating Days of Cover, Safety Buffer, and Estimated Exposure in real time before saving."
- **1:15 – 2:00 | Decision Support on Screen 3 (Insights):**
  "Submitting navigates to Insights. Every output is clearly labelled as a Sample Recommendation from synthetic data. We can inspect the category exposure bars, filter by Critical cases, and mark an item Resolved—which immediately updates the dashboard KPIs."
- **2:00 – 2:45 | Integrity & Architecture on Screen 4 (Workspace):**
  "Finally, in Workspace, we show domain configuration, one-tap synthetic data reset, and our academic integrity compliance: zero real customer data and zero hardcoded API keys."
`
    );

    docs.file(
      '03_Viva_Prep_QA.md',
      `# Task 3 Viva Preparation Questions & Model Answers

1. **How does the app align with Tasks 1 and 2?**
   It translates the exact problem (${domain.businessProblem}) and solution (${domain.proposedSolution}) into a 4-screen mobile decision workflow.
2. **Why are outputs labelled as Sample Model Output?**
   For academic integrity, simulated/deterministic outputs and synthetic datasets must never be misrepresented as live enterprise metrics or live AI predictions.
3. **Where are API keys or credentials stored?**
   No API keys or credentials are hardcoded in the mobile client or APK. The core prototype runs offline using deterministic local logic; any future LLM integration belongs behind a server-side proxy.
4. **How does data flow across the four screens?**
   Records entered on Assess update local state, get evaluated for days of cover and buffer deficit, and immediately refresh Overview KPIs and Insights filters.
`
    );

    docs.file(
      '04_Sample_Dataset.json',
      JSON.stringify(
        {
          disclaimer: 'Synthetic sample data for academic demonstration only.',
          domain: domain.name,
          records,
        },
        null,
        2
      )
    );
  }

  const blob = await zip.generateAsync({type: 'blob'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `VeridianOps_Task3_Pack_${domain.id}.zip`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
