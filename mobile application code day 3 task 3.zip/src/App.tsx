import {useEffect, useMemo, useState} from 'react';
import {BarChart3, ClipboardEdit, LayoutDashboard, Settings2} from 'lucide-react';
import {OfflineIndicator} from './components/OfflineIndicator';
import {PWAInstallButton} from './components/PWAInstallButton';
import {AssessScreen} from './components/screens/AssessScreen';
import {InsightsScreen} from './components/screens/InsightsScreen';
import {OverviewScreen} from './components/screens/OverviewScreen';
import {WorkspaceScreen} from './components/screens/WorkspaceScreen';
import {
  DOMAIN_CONFIGS,
  evaluateOperationalRecord,
  INITIAL_DELIVERABLE_CHECKLIST,
} from './data/domains';
import type {
  BusinessDomainId,
  DeliverableItem,
  EvaluatedRecord,
  OperationalRecordInput,
  ScreenId,
} from './types/business';

const STORAGE_DOMAIN_KEY = 'veridian_ops_domain_v1';
const STORAGE_RECORDS_PREFIX = 'veridian_ops_records_v1_';
const STORAGE_CHECKLIST_KEY = 'veridian_ops_checklist_v1';

const NAV_ITEMS: {id: ScreenId; label: string; icon: typeof LayoutDashboard}[] = [
  {id: 'overview', label: 'Overview', icon: LayoutDashboard},
  {id: 'assess', label: 'Assess', icon: ClipboardEdit},
  {id: 'insights', label: 'Insights', icon: BarChart3},
  {id: 'workspace', label: 'Workspace', icon: Settings2},
];

function loadDomainRecords(domainId: BusinessDomainId): OperationalRecordInput[] {
  try {
    const raw = localStorage.getItem(`${STORAGE_RECORDS_PREFIX}${domainId}`);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch {
    // Fallback to starter dataset
  }
  return DOMAIN_CONFIGS[domainId].starterRecords;
}

export default function App() {
  const [activeScreen, setActiveScreen] = useState<ScreenId>('overview');
  const [domainId, setDomainId] = useState<BusinessDomainId>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_DOMAIN_KEY) as BusinessDomainId | null;
      if (saved && saved in DOMAIN_CONFIGS) return saved;
    } catch {
      // Ignore storage error
    }
    return 'retail';
  });

  const [rawRecords, setRawRecords] = useState<OperationalRecordInput[]>(() =>
    loadDomainRecords(domainId)
  );
  const [editingRecord, setEditingRecord] = useState<EvaluatedRecord | null>(null);
  const [checklist, setChecklist] = useState<DeliverableItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_CHECKLIST_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // Fallback to initial checklist
    }
    return INITIAL_DELIVERABLE_CHECKLIST;
  });

  const domain = DOMAIN_CONFIGS[domainId];

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_DOMAIN_KEY, domainId);
    } catch {
      // Ignore storage error
    }
  }, [domainId]);

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_RECORDS_PREFIX}${domainId}`, JSON.stringify(rawRecords));
    } catch {
      // Ignore storage error
    }
  }, [domainId, rawRecords]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_CHECKLIST_KEY, JSON.stringify(checklist));
    } catch {
      // Ignore storage error
    }
  }, [checklist]);

  const evaluatedRecords = useMemo(
    () => rawRecords.map(evaluateOperationalRecord),
    [rawRecords]
  );

  const handleChangeDomain = (nextId: BusinessDomainId) => {
    setDomainId(nextId);
    setRawRecords(loadDomainRecords(nextId));
    setEditingRecord(null);
  };

  const handleSaveRecord = (input: OperationalRecordInput, isEdit: boolean) => {
    setRawRecords((prev) => {
      if (isEdit) {
        return prev.map((r) => (r.id === input.id ? input : r));
      }
      return [input, ...prev];
    });
    setEditingRecord(null);
    setActiveScreen('insights');
  };

  const handleToggleResolve = (id: string) => {
    setRawRecords((prev) =>
      prev.map((r) =>
        r.id === id
          ? {
              ...r,
              status: r.status === 'Resolved' ? 'Open' : 'Resolved',
              updatedAt: new Date().toISOString().slice(0, 10),
            }
          : r
      )
    );
  };

  const handleDeleteRecord = (id: string) => {
    setRawRecords((prev) => prev.filter((r) => r.id !== id));
    if (editingRecord?.id === id) {
      setEditingRecord(null);
    }
  };

  const handleSelectRecordForAssess = (record: EvaluatedRecord) => {
    setEditingRecord(record);
    setActiveScreen('assess');
  };

  const handleResetSampleData = () => {
    const starter = DOMAIN_CONFIGS[domainId].starterRecords;
    setRawRecords(starter);
    setEditingRecord(null);
  };

  const handleToggleChecklist = (id: string) => {
    setChecklist((prev) =>
      prev.map((item) => (item.id === id ? {...item, completed: !item.completed} : item))
    );
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur-md">
        <div className="mx-auto flex h-13 max-w-7xl items-center justify-between gap-8 px-4 sm:px-6 lg:h-16">
          <button
            type="button"
            onClick={() => setActiveScreen('overview')}
            className="font-display text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0"
          >
            Veridian Ops
          </button>

          <nav className="hidden items-center gap-6 md:flex" aria-label="Primary navigation">
            {NAV_ITEMS.map((item) => {
              const active = activeScreen === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveScreen(item.id)}
                  className={`min-h-[40px] border-b-2 px-1 text-sm font-medium transition-colors whitespace-nowrap shrink-0 ${
                    active
                      ? 'border-blue-700 text-slate-900'
                      : 'border-transparent text-slate-600 hover:border-slate-300 hover:text-slate-900'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          <div className="flex items-center shrink-0">
            <PWAInstallButton variant="header" />
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 pt-6 pb-24 sm:px-6 lg:py-8">
        {activeScreen === 'overview' && (
          <OverviewScreen
            domain={domain}
            records={evaluatedRecords}
            onNavigate={setActiveScreen}
            onSelectRecordForAssess={handleSelectRecordForAssess}
          />
        )}

        {activeScreen === 'assess' && (
          <AssessScreen
            domain={domain}
            editingRecord={editingRecord}
            onSaveRecord={handleSaveRecord}
            onClearEditing={() => setEditingRecord(null)}
          />
        )}

        {activeScreen === 'insights' && (
          <InsightsScreen
            domain={domain}
            records={evaluatedRecords}
            onToggleResolve={handleToggleResolve}
            onEditRecord={handleSelectRecordForAssess}
            onDeleteRecord={handleDeleteRecord}
          />
        )}

        {activeScreen === 'workspace' && (
          <WorkspaceScreen
            domain={domain}
            records={evaluatedRecords}
            checklist={checklist}
            onChangeDomain={handleChangeDomain}
            onResetSampleData={handleResetSampleData}
            onToggleChecklist={handleToggleChecklist}
          />
        )}
      </main>

      <nav
        className="fixed bottom-0 left-0 right-0 z-30 border-t border-slate-200 bg-white/95 backdrop-blur-md pb-safe md:hidden"
        aria-label="Mobile bottom navigation"
      >
        <div className="grid h-15 grid-cols-4 items-center">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = activeScreen === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveScreen(item.id)}
                className={`flex min-h-[44px] flex-col items-center justify-center gap-0.5 px-1 transition-colors ${
                  active ? 'text-blue-700' : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                <Icon className="h-5 w-5" strokeWidth={active ? 2.25 : 1.75} />
                <span className="text-[11px] font-medium tracking-tight whitespace-nowrap">
                  {item.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>

      <OfflineIndicator />
    </div>
  );
}
