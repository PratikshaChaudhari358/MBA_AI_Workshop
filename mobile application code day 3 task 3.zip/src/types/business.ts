export type BusinessDomainId = 'retail' | 'logistics' | 'healthcare' | 'hospitality';

export type ScreenId = 'overview' | 'assess' | 'insights' | 'workspace';

export type RiskLevel = 'Critical' | 'Watchlist' | 'Healthy';

export type PriorityTier = 'Standard' | 'High' | 'Urgent';

export type RecordStatus = 'Open' | 'Resolved';

export interface OperationalRecordInput {
  id: string;
  code: string;
  title: string;
  category: string;
  currentVolume: number;
  dailyDemand: number;
  leadTimeDays: number;
  unitImpactUsd: number;
  priorityTier: PriorityTier;
  status: RecordStatus;
  updatedAt: string;
  notes: string;
}

export interface EvaluatedRecord extends OperationalRecordInput {
  daysOfCover: number;
  safetyBufferDays: number;
  riskLevel: RiskLevel;
  estimatedImpactUsd: number;
  recommendedAction: string;
}

export interface DomainConfig {
  id: BusinessDomainId;
  name: string;
  shortLabel: string;
  businessProblem: string;
  proposedSolution: string;
  itemLabel: string;
  codePlaceholder: string;
  titlePlaceholder: string;
  volumeLabel: string;
  demandLabel: string;
  leadTimeLabel: string;
  impactLabel: string;
  categories: string[];
  starterRecords: OperationalRecordInput[];
}

export interface DeliverableItem {
  id: string;
  title: string;
  detail: string;
  completed: boolean;
}
