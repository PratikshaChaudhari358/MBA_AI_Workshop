import type {
  BusinessDomainId,
  DeliverableItem,
  DomainConfig,
  EvaluatedRecord,
  OperationalRecordInput,
  RiskLevel,
} from '../types/business';

export const DOMAIN_CONFIGS: Record<BusinessDomainId, DomainConfig> = {
  retail: {
    id: 'retail',
    name: 'Retail & Inventory Operations',
    shortLabel: 'Retail Ops',
    businessProblem:
      'High-velocity SKUs suffer unpredicted stockouts during promotional cycles while slow-moving inventory ties up working capital.',
    proposedSolution:
      'Frontline managers log store shelf counts and lead-time shifts to calculate days-of-cover and prioritize replenishment orders.',
    itemLabel: 'SKU / Product Line',
    codePlaceholder: 'SKU-408',
    titlePlaceholder: 'Cold-Pressed Olive Oil 750ml',
    volumeLabel: 'Current On-Hand Units',
    demandLabel: 'Daily Unit Velocity',
    leadTimeLabel: 'Supplier Lead Time (Days)',
    impactLabel: 'Gross Margin per Unit ($)',
    categories: ['Beverages', 'Pantry', 'Fresh Produce', 'Personal Care'],
    starterRecords: [
      {
        id: 'ret-1',
        code: 'SKU-104',
        title: 'Organic Oat Barista Blend 1L',
        category: 'Beverages',
        currentVolume: 120,
        dailyDemand: 38,
        leadTimeDays: 5,
        unitImpactUsd: 2.4,
        priorityTier: 'Urgent',
        status: 'Open',
        updatedAt: '2026-11-22',
        notes: 'Weekend promo increased sell-through by 24% across Zone B stores.',
      },
      {
        id: 'ret-2',
        code: 'SKU-219',
        title: 'Artisan Sourdough Loaf 600g',
        category: 'Fresh Produce',
        currentVolume: 95,
        dailyDemand: 22,
        leadTimeDays: 3,
        unitImpactUsd: 3.1,
        priorityTier: 'High',
        status: 'Open',
        updatedAt: '2026-11-22',
        notes: 'Morning bakery batch arrives 6 hours later on Tuesdays.',
      },
      {
        id: 'ret-3',
        code: 'SKU-342',
        title: 'Botanical Hand Wash Refill 500ml',
        category: 'Personal Care',
        currentVolume: 460,
        dailyDemand: 19,
        leadTimeDays: 7,
        unitImpactUsd: 4.5,
        priorityTier: 'Standard',
        status: 'Open',
        updatedAt: '2026-11-21',
        notes: 'Stable baseline velocity after Q4 shelf reset.',
      },
      {
        id: 'ret-4',
        code: 'SKU-488',
        title: 'Single-Origin Ground Roast 250g',
        category: 'Pantry',
        currentVolume: 64,
        dailyDemand: 16,
        leadTimeDays: 6,
        unitImpactUsd: 5.2,
        priorityTier: 'High',
        status: 'Open',
        updatedAt: '2026-11-22',
        notes: 'Roastery freight carrier flagged 48h port congestion.',
      },
    ],
  },
  logistics: {
    id: 'logistics',
    name: 'Supply Chain & Fleet Dispatch',
    shortLabel: 'Logistics',
    businessProblem:
      'Regional hubs experience missed SLA delivery windows due to fragmented visibility into container backlog and carrier turnaround times.',
    proposedSolution:
      'Dispatch supervisors assess lane throughput and dock capacity to flag SLA bottlenecks and rebalance freight carriers.',
    itemLabel: 'Freight Lane / Hub',
    codePlaceholder: 'LANE-N12',
    titlePlaceholder: 'North Hub Cross-Dock Pallet Pool',
    volumeLabel: 'Available Dock / Fleet Capacity',
    demandLabel: 'Daily Inbound Pallet Load',
    leadTimeLabel: 'Carrier Turnaround (Days)',
    impactLabel: 'SLA Penalty / Unit ($)',
    categories: ['Cold Chain', 'Last Mile', 'Cross-Dock', 'Linehaul'],
    starterRecords: [
      {
        id: 'log-1',
        code: 'LANE-09',
        title: 'Midwest Refrigerated Express',
        category: 'Cold Chain',
        currentVolume: 48,
        dailyDemand: 18,
        leadTimeDays: 4,
        unitImpactUsd: 85,
        priorityTier: 'Urgent',
        status: 'Open',
        updatedAt: '2026-11-22',
        notes: 'Two reefer trailers scheduled for preventive inspection.',
      },
      {
        id: 'log-2',
        code: 'LANE-14',
        title: 'Metro Zone 3 Parcel Vans',
        category: 'Last Mile',
        currentVolume: 140,
        dailyDemand: 32,
        leadTimeDays: 2,
        unitImpactUsd: 42,
        priorityTier: 'High',
        status: 'Open',
        updatedAt: '2026-11-22',
        notes: 'Holiday parcel volume trending 18% above baseline.',
      },
      {
        id: 'log-3',
        code: 'LANE-27',
        title: 'Port Terminal Staging Bays',
        category: 'Cross-Dock',
        currentVolume: 310,
        dailyDemand: 24,
        leadTimeDays: 5,
        unitImpactUsd: 65,
        priorityTier: 'Standard',
        status: 'Open',
        updatedAt: '2026-11-21',
        notes: 'Customs clearance cycle remains within target window.',
      },
    ],
  },
  healthcare: {
    id: 'healthcare',
    name: 'Outpatient Clinic Operations',
    shortLabel: 'Clinic Flow',
    businessProblem:
      'Outpatient departments face unpredictable diagnostic queue backlogs and consumable kit shortages during peak clinic hours.',
    proposedSolution:
      'Clinic coordinators track anonymized slot capacity and consumable kit burn rates to rebalance nurse shifts and supply orders.',
    itemLabel: 'Clinic Unit / Kit',
    codePlaceholder: 'UNIT-C04',
    titlePlaceholder: 'Diagnostic Phlebotomy Kit Pool',
    volumeLabel: 'Available Kits / Slots',
    demandLabel: 'Daily Patient Volume',
    leadTimeLabel: 'Restock / Rotation (Days)',
    impactLabel: 'Operational Cost / Delay ($)',
    categories: ['Diagnostics', 'Primary Care', 'Pharmacy', 'Sterile Supply'],
    starterRecords: [
      {
        id: 'hlt-1',
        code: 'KIT-301',
        title: 'Rapid Point-of-Care Assay Packs',
        category: 'Diagnostics',
        currentVolume: 85,
        dailyDemand: 28,
        leadTimeDays: 4,
        unitImpactUsd: 18,
        priorityTier: 'Urgent',
        status: 'Open',
        updatedAt: '2026-11-22',
        notes: 'Synthetic sample data: seasonal respiratory clinic surge.',
      },
      {
        id: 'hlt-2',
        code: 'SLOT-12',
        title: 'Morning Triage Nurse Capacity',
        category: 'Primary Care',
        currentVolume: 160,
        dailyDemand: 36,
        leadTimeDays: 3,
        unitImpactUsd: 26,
        priorityTier: 'High',
        status: 'Open',
        updatedAt: '2026-11-22',
        notes: 'Synthetic sample data: Monday walk-in block requires buffer.',
      },
      {
        id: 'hlt-3',
        code: 'PHM-08',
        title: 'Standard Infusion Prep Trays',
        category: 'Sterile Supply',
        currentVolume: 420,
        dailyDemand: 20,
        leadTimeDays: 6,
        unitImpactUsd: 14,
        priorityTier: 'Standard',
        status: 'Open',
        updatedAt: '2026-11-21',
        notes: 'Synthetic sample data: central pharmacy par level healthy.',
      },
    ],
  },
  hospitality: {
    id: 'hospitality',
    name: 'Hospitality & Guest Operations',
    shortLabel: 'Hospitality',
    businessProblem:
      'Boutique properties lose revenue when room turnaround delays clash with peak check-in waves and amenity stock shortfalls.',
    proposedSolution:
      'Duty managers evaluate housekeeping capacity and amenity par levels to sequence turnarounds and prevent check-in bottlenecks.',
    itemLabel: 'Property Resource',
    codePlaceholder: 'OPS-H07',
    titlePlaceholder: 'Executive Suite Linen Par Set',
    volumeLabel: 'Ready Units / Staff Hours',
    demandLabel: 'Daily Turnover Demand',
    leadTimeLabel: 'Laundry / Vendor Cycle (Days)',
    impactLabel: 'Guest Recovery Cost ($)',
    categories: ['Housekeeping', 'F&B Prep', 'Guest Amenities', 'Banquets'],
    starterRecords: [
      {
        id: 'hos-1',
        code: 'HSK-11',
        title: 'Deluxe Wing Room Turnaround Hours',
        category: 'Housekeeping',
        currentVolume: 52,
        dailyDemand: 18,
        leadTimeDays: 3,
        unitImpactUsd: 45,
        priorityTier: 'Urgent',
        status: 'Open',
        updatedAt: '2026-11-22',
        notes: 'Conference group check-in concentrated between 14:00 and 16:00.',
      },
      {
        id: 'hos-2',
        code: 'FB-204',
        title: 'Breakfast Buffet Cold-Press Stock',
        category: 'F&B Prep',
        currentVolume: 190,
        dailyDemand: 42,
        leadTimeDays: 3,
        unitImpactUsd: 8.5,
        priorityTier: 'High',
        status: 'Open',
        updatedAt: '2026-11-22',
        notes: 'Weekend occupancy forecast at 91%.',
      },
      {
        id: 'hos-3',
        code: 'AMN-05',
        title: 'Spa Welcome Kit Inventory',
        category: 'Guest Amenities',
        currentVolume: 540,
        dailyDemand: 25,
        leadTimeDays: 5,
        unitImpactUsd: 12,
        priorityTier: 'Standard',
        status: 'Open',
        updatedAt: '2026-11-21',
        notes: 'Vendor replenishment batch confirmed for next Friday.',
      },
    ],
  },
};

export function evaluateOperationalRecord(record: OperationalRecordInput): EvaluatedRecord {
  const safeDemand = Math.max(record.dailyDemand, 0.1);
  const daysOfCover = Number((record.currentVolume / safeDemand).toFixed(1));
  const safetyBufferDays = Number((daysOfCover - record.leadTimeDays).toFixed(1));

  let riskLevel: RiskLevel = 'Healthy';
  if (record.status === 'Resolved') {
    riskLevel = 'Healthy';
  } else if (safetyBufferDays <= 0 || daysOfCover <= 2.5) {
    riskLevel = 'Critical';
  } else if (safetyBufferDays <= 3 || record.priorityTier === 'Urgent') {
    riskLevel = 'Watchlist';
  }

  const shortfallDays = Math.max(0, record.leadTimeDays + 2 - daysOfCover);
  const unitsAtRisk = Math.round(shortfallDays * record.dailyDemand);
  const estimatedImpactUsd =
    record.status === 'Resolved' ? 0 : Math.round(unitsAtRisk * record.unitImpactUsd);

  let recommendedAction = 'Maintain standard cycle cadence and review at weekly audit.';
  if (record.status === 'Resolved') {
    recommendedAction = 'Marked resolved in local register. Monitor on next cycle.';
  } else if (riskLevel === 'Critical') {
    const emergencyQty = Math.max(
      Math.round(record.dailyDemand * (record.leadTimeDays + 4) - record.currentVolume),
      Math.round(record.dailyDemand * 3)
    );
    recommendedAction = `Expedite replenishment of ${emergencyQty} units immediately to close a ${Math.abs(
      safetyBufferDays
    ).toFixed(1)}-day buffer deficit.`;
  } else if (riskLevel === 'Watchlist') {
    const reorderQty = Math.max(
      Math.round(record.dailyDemand * (record.leadTimeDays + 5) - record.currentVolume),
      Math.round(record.dailyDemand * 2)
    );
    recommendedAction = `Schedule preventive order of ${reorderQty} units within 24 hours before buffer dips below lead time.`;
  }

  return {
    ...record,
    daysOfCover,
    safetyBufferDays,
    riskLevel,
    estimatedImpactUsd,
    recommendedAction,
  };
}

export const INITIAL_DELIVERABLE_CHECKLIST: DeliverableItem[] = [
  {
    id: 'deliv-align',
    title: 'Align app with Tasks 1 & 2 business domain',
    detail: 'Verify domain profile, problem statement, and solution workflow match your report.',
    completed: true,
  },
  {
    id: 'deliv-4screens',
    title: 'Verify 4 minimum required mobile screens',
    detail: 'Overview, Assess (Input), Insights (Decisions), and Workspace (Records & Settings).',
    completed: true,
  },
  {
    id: 'deliv-synthetic',
    title: 'Confirm synthetic/anonymised data labelling',
    detail: 'All sample records are non-personal and clearly labelled as sample outputs.',
    completed: true,
  },
  {
    id: 'deliv-apk',
    title: 'Build working APK in Android Studio',
    detail: 'Download the Kotlin Compose ZIP below, open in Android Studio, and Build APK.',
    completed: false,
  },
  {
    id: 'deliv-shots',
    title: 'Capture at least 4 device/emulator screenshots',
    detail: 'Capture Overview, Assess, Insights, and Workspace screens for your appendix.',
    completed: false,
  },
  {
    id: 'deliv-video',
    title: 'Record 2–3 minute walkthrough video',
    detail: 'Demonstrate navigation, new entry assessment, live decision update, and data disclaimer.',
    completed: false,
  },
];
