import React from 'react';
import {AlertTriangle, ArrowRight, CheckCircle2, Clock, Plus} from 'lucide-react';
import type {DomainConfig, EvaluatedRecord, ScreenId} from '../../types/business';

interface OverviewScreenProps {
  domain: DomainConfig;
  records: EvaluatedRecord[];
  onNavigate: (screen: ScreenId) => void;
  onSelectRecordForAssess: (record: EvaluatedRecord) => void;
}

export const OverviewScreen: React.FC<OverviewScreenProps> = ({
  domain,
  records,
  onNavigate,
  onSelectRecordForAssess,
}) => {
  const openRecords = records.filter((r) => r.status === 'Open');
  const criticalCount = openRecords.filter((r) => r.riskLevel === 'Critical').length;
  const watchlistCount = openRecords.filter((r) => r.riskLevel === 'Watchlist').length;
  const avgCover =
    openRecords.length > 0
      ? (openRecords.reduce((acc, r) => acc + r.daysOfCover, 0) / openRecords.length).toFixed(1)
      : '0.0';
  const totalExposure = openRecords.reduce((acc, r) => acc + r.estimatedImpactUsd, 0);

  const prioritized = [...records].sort((a, b) => {
    const order = {Critical: 0, Watchlist: 1, Healthy: 2};
    if (a.status !== b.status) return a.status === 'Open' ? -1 : 1;
    return order[a.riskLevel] - order[b.riskLevel];
  });

  return (
    <div className="space-y-8">
      <section className="grid gap-6 lg:grid-cols-12 lg:items-stretch">
        <div className="rounded-2xl border border-slate-200 bg-white p-6 lg:col-span-8">
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
            <span>{domain.shortLabel}</span>
            <span aria-hidden="true">·</span>
            <span>Synthetic sample dataset</span>
            <span aria-hidden="true">·</span>
            <span>Local device storage</span>
          </div>
          <h1 className="mt-2 text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl text-balance">
            {domain.name}
          </h1>
          <p className="mt-2 max-w-2xl text-sm leading-relaxed text-slate-600 sm:text-base">
            {domain.businessProblem}
          </p>
          <div className="mt-5 flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => onNavigate('assess')}
              className="inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-blue-700 px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-blue-800 whitespace-nowrap shrink-0"
            >
              <Plus className="h-4 w-4" />
              <span>Run New Assessment</span>
            </button>
            <button
              type="button"
              onClick={() => onNavigate('insights')}
              className="inline-flex min-h-[44px] items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-4 py-2.5 text-sm font-medium text-slate-700 transition-colors hover:bg-slate-100 whitespace-nowrap shrink-0"
            >
              <span>Inspect Sample Decisions</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>

        <div className="flex flex-col justify-between rounded-2xl border border-slate-200 bg-slate-900 p-6 text-white lg:col-span-4">
          <div>
            <p className="text-xs font-medium text-slate-300">Proposed Solution Alignment</p>
            <p className="mt-2 text-sm leading-relaxed text-slate-100">{domain.proposedSolution}</p>
          </div>
          <div className="mt-6 border-t border-slate-800 pt-4 flex items-center justify-between text-xs text-slate-300">
            <span>Active priority alerts</span>
            <span className="font-mono text-sm font-semibold text-white tabular-nums">
              {criticalCount + watchlistCount} / {openRecords.length} open
            </span>
          </div>
        </div>
      </section>

      <section aria-label="Operational key performance indicators">
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <div className="rounded-2xl border border-slate-200 bg-white p-5">
            <p className="text-xs font-medium text-slate-500">Open Operational Cases</p>
            <p className="mt-2 font-mono text-2xl font-bold text-slate-900 tabular-nums sm:text-3xl">
              {openRecords.length}
            </p>
            <p className="mt-1 text-xs text-slate-500 tabular-nums">
              {records.length - openRecords.length} resolved in register
            </p>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-5">
            <p className="text-xs font-medium text-slate-500">Critical Attention</p>
            <p className="mt-2 font-mono text-2xl font-bold text-rose-700 tabular-nums sm:text-3xl">
              {criticalCount}
            </p>
            <p className="mt-1 text-xs text-slate-500 tabular-nums">
              {watchlistCount} on watchlist
            </p>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-5">
            <p className="text-xs font-medium text-slate-500">Average Cover Window</p>
            <p className="mt-2 font-mono text-2xl font-bold text-slate-900 tabular-nums sm:text-3xl">
              {avgCover}d
            </p>
            <p className="mt-1 text-xs text-slate-500">Sample model baseline</p>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-5">
            <p className="text-xs font-medium text-slate-500">Projected Risk Exposure</p>
            <p className="mt-2 font-mono text-2xl font-bold text-slate-900 tabular-nums sm:text-3xl">
              ${totalExposure.toLocaleString()}
            </p>
            <p className="mt-1 text-xs text-slate-500">Estimated sample impact</p>
          </div>
        </div>
      </section>

      <section className="rounded-2xl border border-slate-200 bg-white">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 px-6 py-4">
          <div>
            <h2 className="text-lg font-semibold text-slate-900">Operational Priority Queue</h2>
            <p className="text-xs text-slate-500">
              Select any item to adjust inputs in Assess or review its sample action plan.
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('insights')}
            className="min-h-[40px] text-sm font-medium text-blue-700 hover:text-blue-800 whitespace-nowrap"
          >
            Open Decision Insights
          </button>
        </div>

        <div className="divide-y divide-slate-100">
          {prioritized.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => onSelectRecordForAssess(item)}
              className="flex min-h-[68px] w-full items-center justify-between gap-4 px-6 py-4 text-left transition-colors hover:bg-slate-50"
            >
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                  <span className="font-mono font-medium text-slate-700">{item.code}</span>
                  <span aria-hidden="true">·</span>
                  <span>{item.category}</span>
                  <span aria-hidden="true">·</span>
                  <span className="inline-flex items-center gap-1 font-medium text-slate-700">
                    {item.riskLevel === 'Critical' && (
                      <AlertTriangle className="h-3.5 w-3.5 text-rose-600" aria-hidden="true" />
                    )}
                    {item.riskLevel === 'Watchlist' && (
                      <Clock className="h-3.5 w-3.5 text-amber-600" aria-hidden="true" />
                    )}
                    {item.riskLevel === 'Healthy' && (
                      <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" aria-hidden="true" />
                    )}
                    <span
                      className={
                        item.riskLevel === 'Critical'
                          ? 'text-rose-700'
                          : item.riskLevel === 'Watchlist'
                            ? 'text-amber-700'
                            : 'text-emerald-700'
                      }
                    >
                      {item.status === 'Resolved' ? 'Resolved' : item.riskLevel}
                    </span>
                  </span>
                </div>
                <p className="mt-1 truncate text-sm font-semibold text-slate-900">{item.title}</p>
                <p className="mt-0.5 truncate text-xs text-slate-600">{item.recommendedAction}</p>
              </div>

              <div className="shrink-0 text-right">
                <p className="font-mono text-sm font-semibold text-slate-900 tabular-nums">
                  {item.daysOfCover}d cover
                </p>
                <p className="mt-0.5 font-mono text-xs text-slate-500 tabular-nums">
                  ${item.estimatedImpactUsd.toLocaleString()}
                </p>
              </div>
            </button>
          ))}
        </div>
      </section>
    </div>
  );
};
