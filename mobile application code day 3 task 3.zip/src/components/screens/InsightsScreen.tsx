import React, {useMemo, useState} from 'react';
import {AlertTriangle, CheckCircle2, Clock, Edit3, Trash2} from 'lucide-react';
import type {DomainConfig, EvaluatedRecord, RiskLevel} from '../../types/business';

interface InsightsScreenProps {
  domain: DomainConfig;
  records: EvaluatedRecord[];
  onToggleResolve: (id: string) => void;
  onEditRecord: (record: EvaluatedRecord) => void;
  onDeleteRecord: (id: string) => void;
}

type FilterOption = 'All' | RiskLevel | 'Resolved';

export const InsightsScreen: React.FC<InsightsScreenProps> = ({
  domain,
  records,
  onToggleResolve,
  onEditRecord,
  onDeleteRecord,
}) => {
  const [filter, setFilter] = useState<FilterOption>('All');

  const filteredRecords = useMemo(() => {
    if (filter === 'All') return records;
    if (filter === 'Resolved') return records.filter((r) => r.status === 'Resolved');
    return records.filter((r) => r.status === 'Open' && r.riskLevel === filter);
  }, [records, filter]);

  const categoryBreakdown = useMemo(() => {
    const totals = new Map<string, number>();
    for (const cat of domain.categories) {
      totals.set(cat, 0);
    }
    for (const r of records) {
      if (r.status === 'Open') {
        totals.set(r.category, (totals.get(r.category) ?? 0) + r.estimatedImpactUsd);
      }
    }
    const maxVal = Math.max(1, ...Array.from(totals.values()));
    return Array.from(totals.entries()).map(([category, amount]) => ({
      category,
      amount,
      widthPct: Math.round((amount / maxVal) * 100),
    }));
  }, [domain.categories, records]);

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-slate-200 bg-white p-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="text-xs text-slate-500">
              Sample model outputs · Synthetic records only · Clearly labelled for academic review
            </p>
            <h1 className="mt-1 text-2xl font-bold tracking-tight text-slate-900">
              Decision Insights & Action Queue
            </h1>
          </div>

          <div className="flex flex-wrap items-center gap-1 rounded-xl bg-slate-100 p-1">
            {(['All', 'Critical', 'Watchlist', 'Healthy', 'Resolved'] as FilterOption[]).map(
              (option) => (
                <button
                  key={option}
                  type="button"
                  onClick={() => setFilter(option)}
                  className={`min-h-[38px] rounded-lg px-3 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                    filter === option
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {option}
                </button>
              )
            )}
          </div>
        </div>
      </div>

      <section className="rounded-2xl border border-slate-200 bg-white p-6">
        <div className="flex items-baseline justify-between gap-4">
          <h2 className="text-base font-semibold text-slate-900">
            Estimated Financial Exposure by Category (Sample Output)
          </h2>
          <span className="text-xs text-slate-500">Open cases only</span>
        </div>
        <div className="mt-4 space-y-3">
          {categoryBreakdown.map((row) => (
            <div key={row.category} className="grid grid-cols-12 items-center gap-3">
              <span className="col-span-4 truncate text-xs font-medium text-slate-700 sm:col-span-3">
                {row.category}
              </span>
              <div className="col-span-5 h-3 overflow-hidden rounded-full bg-slate-100 sm:col-span-7">
                <div
                  className="h-full rounded-full bg-blue-700 transition-all"
                  style={{width: `${row.widthPct}%`}}
                />
              </div>
              <span className="col-span-3 text-right font-mono text-xs font-semibold text-slate-900 tabular-nums sm:col-span-2">
                ${row.amount.toLocaleString()}
              </span>
            </div>
          ))}
        </div>
      </section>

      {filteredRecords.length === 0 ? (
        <div className="rounded-2xl border border-slate-200 bg-white p-8 text-center">
          <p className="text-sm font-medium text-slate-900">No items match the "{filter}" filter.</p>
          <p className="mt-1 text-xs text-slate-500">
            Switch filters above or log a new assessment in the Assess tab.
          </p>
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {filteredRecords.map((item) => (
            <article
              key={item.id}
              className="flex flex-col justify-between rounded-2xl border border-slate-200 bg-white p-5"
            >
              <div>
                <div className="flex items-center justify-between gap-3">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                    <span className="font-mono font-semibold text-slate-800">{item.code}</span>
                    <span aria-hidden="true">·</span>
                    <span>{item.category}</span>
                    <span aria-hidden="true">·</span>
                    <span>Updated {item.updatedAt}</span>
                  </div>
                  <span className="inline-flex items-center gap-1 text-xs font-semibold shrink-0">
                    {item.status === 'Resolved' ? (
                      <>
                        <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" aria-hidden="true" />
                        <span className="text-emerald-700">Resolved</span>
                      </>
                    ) : item.riskLevel === 'Critical' ? (
                      <>
                        <AlertTriangle className="h-3.5 w-3.5 text-rose-600" aria-hidden="true" />
                        <span className="text-rose-700">Critical</span>
                      </>
                    ) : item.riskLevel === 'Watchlist' ? (
                      <>
                        <Clock className="h-3.5 w-3.5 text-amber-600" aria-hidden="true" />
                        <span className="text-amber-700">Watchlist</span>
                      </>
                    ) : (
                      <>
                        <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" aria-hidden="true" />
                        <span className="text-emerald-700">Healthy</span>
                      </>
                    )}
                  </span>
                </div>

                <h3 className="mt-2 text-base font-semibold text-slate-900">{item.title}</h3>

                <div className="mt-3 grid grid-cols-3 gap-2 rounded-xl bg-slate-50 p-3 text-center">
                  <div>
                    <p className="text-[11px] text-slate-500">Cover</p>
                    <p className="font-mono text-sm font-bold text-slate-900 tabular-nums">
                      {item.daysOfCover}d
                    </p>
                  </div>
                  <div>
                    <p className="text-[11px] text-slate-500">Buffer</p>
                    <p className="font-mono text-sm font-bold text-slate-900 tabular-nums">
                      {item.safetyBufferDays > 0 ? '+' : ''}
                      {item.safetyBufferDays}d
                    </p>
                  </div>
                  <div>
                    <p className="text-[11px] text-slate-500">Exposure</p>
                    <p className="font-mono text-sm font-bold text-slate-900 tabular-nums">
                      ${item.estimatedImpactUsd.toLocaleString()}
                    </p>
                  </div>
                </div>

                <p className="mt-3 text-xs font-medium text-slate-500">Sample Recommendation</p>
                <p className="mt-1 text-sm leading-relaxed text-slate-700">{item.recommendedAction}</p>
                {item.notes && <p className="mt-2 text-xs text-slate-500">{item.notes}</p>}
              </div>

              <div className="mt-4 flex flex-wrap items-center justify-between gap-2 border-t border-slate-100 pt-3">
                <button
                  type="button"
                  onClick={() => onToggleResolve(item.id)}
                  className="min-h-[40px] rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-800 hover:bg-slate-50 whitespace-nowrap"
                >
                  {item.status === 'Resolved' ? 'Reopen Case' : 'Mark Resolved'}
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => onEditRecord(item)}
                    aria-label={`Edit ${item.title}`}
                    className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50"
                  >
                    <Edit3 className="h-3.5 w-3.5" />
                    <span>Edit</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onDeleteRecord(item.id)}
                    aria-label={`Delete ${item.title}`}
                    className="inline-flex min-h-[40px] min-w-[40px] items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-500 hover:border-rose-200 hover:bg-rose-50 hover:text-rose-700"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
};
