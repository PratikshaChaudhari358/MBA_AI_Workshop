import React, {useEffect, useMemo, useState} from 'react';
import {CheckCircle2, RotateCcw} from 'lucide-react';
import {evaluateOperationalRecord} from '../../data/domains';
import type {
  DomainConfig,
  EvaluatedRecord,
  OperationalRecordInput,
  PriorityTier,
} from '../../types/business';

interface AssessScreenProps {
  domain: DomainConfig;
  editingRecord: EvaluatedRecord | null;
  onSaveRecord: (input: OperationalRecordInput, isEdit: boolean) => void;
  onClearEditing: () => void;
}

export const AssessScreen: React.FC<AssessScreenProps> = ({
  domain,
  editingRecord,
  onSaveRecord,
  onClearEditing,
}) => {
  const [code, setCode] = useState(domain.codePlaceholder);
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState(domain.categories[0]);
  const [currentVolume, setCurrentVolume] = useState('90');
  const [dailyDemand, setDailyDemand] = useState('28');
  const [leadTimeDays, setLeadTimeDays] = useState('4');
  const [unitImpactUsd, setUnitImpactUsd] = useState('12');
  const [priorityTier, setPriorityTier] = useState<PriorityTier>('High');
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (editingRecord) {
      setCode(editingRecord.code);
      setTitle(editingRecord.title);
      setCategory(
        domain.categories.includes(editingRecord.category)
          ? editingRecord.category
          : domain.categories[0]
      );
      setCurrentVolume(String(editingRecord.currentVolume));
      setDailyDemand(String(editingRecord.dailyDemand));
      setLeadTimeDays(String(editingRecord.leadTimeDays));
      setUnitImpactUsd(String(editingRecord.unitImpactUsd));
      setPriorityTier(editingRecord.priorityTier);
      setNotes(editingRecord.notes);
    } else {
      setCode(domain.codePlaceholder);
      setTitle('');
      setCategory(domain.categories[0]);
      setCurrentVolume('90');
      setDailyDemand('28');
      setLeadTimeDays('4');
      setUnitImpactUsd('12');
      setPriorityTier('High');
      setNotes('');
    }
  }, [editingRecord, domain]);

  const livePreview = useMemo(() => {
    const sampleInput: OperationalRecordInput = {
      id: editingRecord?.id ?? 'preview',
      code: code.trim() || domain.codePlaceholder,
      title: title.trim() || domain.titlePlaceholder,
      category,
      currentVolume: Math.max(0, Number(currentVolume) || 0),
      dailyDemand: Math.max(1, Number(dailyDemand) || 1),
      leadTimeDays: Math.max(1, Number(leadTimeDays) || 1),
      unitImpactUsd: Math.max(0, Number(unitImpactUsd) || 0),
      priorityTier,
      status: editingRecord?.status ?? 'Open',
      updatedAt: new Date().toISOString().slice(0, 10),
      notes: notes.trim(),
    };
    return evaluateOperationalRecord(sampleInput);
  }, [
    editingRecord,
    code,
    domain.codePlaceholder,
    domain.titlePlaceholder,
    title,
    category,
    currentVolume,
    dailyDemand,
    leadTimeDays,
    unitImpactUsd,
    priorityTier,
    notes,
  ]);

  const applyPreset = (preset: 'critical' | 'watchlist' | 'healthy') => {
    onClearEditing();
    if (preset === 'critical') {
      setCode(`${domain.codePlaceholder}-A`);
      setTitle(`Peak Surge ${domain.itemLabel}`);
      setCurrentVolume('60');
      setDailyDemand('30');
      setLeadTimeDays('5');
      setUnitImpactUsd('18');
      setPriorityTier('Urgent');
      setNotes('Synthetic stress test: promotional spike exceeds current lead-time buffer.');
    } else if (preset === 'watchlist') {
      setCode(`${domain.codePlaceholder}-B`);
      setTitle(`Standard Cycle ${domain.itemLabel}`);
      setCurrentVolume('150');
      setDailyDemand('25');
      setLeadTimeDays('4');
      setUnitImpactUsd('10');
      setPriorityTier('High');
      setNotes('Synthetic watchlist test: buffer within 2 days of supplier turnaround.');
    } else {
      setCode(`${domain.codePlaceholder}-C`);
      setTitle(`Buffered Baseline ${domain.itemLabel}`);
      setCurrentVolume('380');
      setDailyDemand('20');
      setLeadTimeDays('5');
      setUnitImpactUsd('8');
      setPriorityTier('Standard');
      setNotes('Synthetic healthy baseline: ample safety stock above lead-time window.');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const record: OperationalRecordInput = {
      id: editingRecord?.id ?? `rec-${Date.now()}`,
      code: code.trim() || domain.codePlaceholder,
      title: title.trim() || domain.titlePlaceholder,
      category,
      currentVolume: Math.max(0, Number(currentVolume) || 0),
      dailyDemand: Math.max(1, Number(dailyDemand) || 1),
      leadTimeDays: Math.max(1, Number(leadTimeDays) || 1),
      unitImpactUsd: Math.max(0, Number(unitImpactUsd) || 0),
      priorityTier,
      status: editingRecord?.status ?? 'Open',
      updatedAt: new Date().toISOString().slice(0, 10),
      notes: notes.trim(),
    };
    onSaveRecord(record, !!editingRecord);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-xs text-slate-500">
            {domain.shortLabel} · Synthetic input form · Deterministic sample evaluation
          </p>
          <h1 className="mt-1 text-2xl font-bold tracking-tight text-slate-900">
            {editingRecord ? `Update ${editingRecord.code}` : 'Operational Assessment'}
          </h1>
        </div>
        {editingRecord && (
          <button
            type="button"
            onClick={onClearEditing}
            className="inline-flex min-h-[40px] items-center gap-2 rounded-xl border border-slate-200 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            <span>Switch to New Entry</span>
          </button>
        )}
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <span className="text-xs font-medium text-slate-500 mr-1">Load sample scenario:</span>
        <button
          type="button"
          onClick={() => applyPreset('critical')}
          className="min-h-[38px] rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap"
        >
          Critical Deficit
        </button>
        <button
          type="button"
          onClick={() => applyPreset('watchlist')}
          className="min-h-[38px] rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap"
        >
          Watchlist Buffer
        </button>
        <button
          type="button"
          onClick={() => applyPreset('healthy')}
          className="min-h-[38px] rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap"
        >
          Healthy Baseline
        </button>
      </div>

      <div className="grid gap-6 lg:grid-cols-12 lg:items-start">
        <form
          onSubmit={handleSubmit}
          className="space-y-5 rounded-2xl border border-slate-200 bg-white p-6 lg:col-span-7"
        >
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="op-code" className="block text-xs font-medium text-slate-700">
                Reference Code (Synthetic)
              </label>
              <input
                id="op-code"
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder={domain.codePlaceholder}
                className="mt-1.5 min-h-[44px] w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 text-sm font-mono text-slate-900 focus:border-blue-600 focus:bg-white focus:outline-none"
              />
            </div>

            <div>
              <label htmlFor="op-category" className="block text-xs font-medium text-slate-700">
                Operational Category
              </label>
              <select
                id="op-category"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="mt-1.5 min-h-[44px] w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 text-sm text-slate-900 focus:border-blue-600 focus:bg-white focus:outline-none"
              >
                {domain.categories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label htmlFor="op-title" className="block text-xs font-medium text-slate-700">
              {domain.itemLabel} Name
            </label>
            <input
              id="op-title"
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={domain.titlePlaceholder}
              className="mt-1.5 min-h-[44px] w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 text-sm text-slate-900 focus:border-blue-600 focus:bg-white focus:outline-none"
            />
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="op-volume" className="block text-xs font-medium text-slate-700">
                {domain.volumeLabel}
              </label>
              <input
                id="op-volume"
                type="number"
                min="0"
                value={currentVolume}
                onChange={(e) => setCurrentVolume(e.target.value)}
                className="mt-1.5 min-h-[44px] w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 text-sm font-mono tabular-nums text-slate-900 focus:border-blue-600 focus:bg-white focus:outline-none"
              />
            </div>

            <div>
              <label htmlFor="op-demand" className="block text-xs font-medium text-slate-700">
                {domain.demandLabel}
              </label>
              <input
                id="op-demand"
                type="number"
                min="1"
                value={dailyDemand}
                onChange={(e) => setDailyDemand(e.target.value)}
                className="mt-1.5 min-h-[44px] w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 text-sm font-mono tabular-nums text-slate-900 focus:border-blue-600 focus:bg-white focus:outline-none"
              />
            </div>

            <div>
              <label htmlFor="op-lead" className="block text-xs font-medium text-slate-700">
                {domain.leadTimeLabel}
              </label>
              <input
                id="op-lead"
                type="number"
                min="1"
                value={leadTimeDays}
                onChange={(e) => setLeadTimeDays(e.target.value)}
                className="mt-1.5 min-h-[44px] w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 text-sm font-mono tabular-nums text-slate-900 focus:border-blue-600 focus:bg-white focus:outline-none"
              />
            </div>

            <div>
              <label htmlFor="op-impact" className="block text-xs font-medium text-slate-700">
                {domain.impactLabel}
              </label>
              <input
                id="op-impact"
                type="number"
                min="0"
                step="0.5"
                value={unitImpactUsd}
                onChange={(e) => setUnitImpactUsd(e.target.value)}
                className="mt-1.5 min-h-[44px] w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 text-sm font-mono tabular-nums text-slate-900 focus:border-blue-600 focus:bg-white focus:outline-none"
              />
            </div>
          </div>

          <div>
            <span className="block text-xs font-medium text-slate-700">Priority Tier</span>
            <div className="mt-1.5 grid grid-cols-3 gap-1.5 rounded-xl bg-slate-100 p-1">
              {(['Standard', 'High', 'Urgent'] as PriorityTier[]).map((tier) => (
                <button
                  key={tier}
                  type="button"
                  onClick={() => setPriorityTier(tier)}
                  className={`min-h-[40px] rounded-lg px-3 text-xs font-medium transition-colors ${
                    priorityTier === tier
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {tier}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label htmlFor="op-notes" className="block text-xs font-medium text-slate-700">
              Operational Notes (Non-Personal Context)
            </label>
            <textarea
              id="op-notes"
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Optional synthetic shift or supplier context..."
              className="mt-1.5 w-full rounded-xl border border-slate-200 bg-slate-50 p-3.5 text-sm text-slate-900 focus:border-blue-600 focus:bg-white focus:outline-none"
            />
          </div>

          <button
            type="submit"
            className="inline-flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl bg-blue-700 px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-blue-800"
          >
            <CheckCircle2 className="h-4 w-4" />
            <span>{editingRecord ? 'Save Updated Assessment' : 'Save & View Sample Recommendation'}</span>
          </button>
        </form>

        <aside className="rounded-2xl border border-slate-200 bg-white p-6 lg:col-span-5">
          <p className="text-xs font-medium text-slate-500">
            Live Sample Model Preview · Deterministic Rules
          </p>
          <h2 className="mt-1 text-lg font-semibold text-slate-900">{livePreview.title}</h2>
          <p className="mt-1 text-xs text-slate-500">
            {livePreview.code} · {livePreview.category} · {livePreview.priorityTier}
          </p>

          <div className="mt-5 grid grid-cols-2 gap-3">
            <div className="rounded-xl bg-slate-50 p-4">
              <p className="text-xs text-slate-500">Days of Cover</p>
              <p className="mt-1 font-mono text-xl font-bold text-slate-900 tabular-nums">
                {livePreview.daysOfCover}d
              </p>
            </div>
            <div className="rounded-xl bg-slate-50 p-4">
              <p className="text-xs text-slate-500">Safety Buffer</p>
              <p
                className={`mt-1 font-mono text-xl font-bold tabular-nums ${
                  livePreview.safetyBufferDays <= 0 ? 'text-rose-700' : 'text-slate-900'
                }`}
              >
                {livePreview.safetyBufferDays > 0 ? '+' : ''}
                {livePreview.safetyBufferDays}d
              </p>
            </div>
            <div className="rounded-xl bg-slate-50 p-4">
              <p className="text-xs text-slate-500">Risk State</p>
              <p
                className={`mt-1 text-base font-bold ${
                  livePreview.riskLevel === 'Critical'
                    ? 'text-rose-700'
                    : livePreview.riskLevel === 'Watchlist'
                      ? 'text-amber-700'
                      : 'text-emerald-700'
                }`}
              >
                {livePreview.riskLevel}
              </p>
            </div>
            <div className="rounded-xl bg-slate-50 p-4">
              <p className="text-xs text-slate-500">Est. Exposure</p>
              <p className="mt-1 font-mono text-xl font-bold text-slate-900 tabular-nums">
                ${livePreview.estimatedImpactUsd.toLocaleString()}
              </p>
            </div>
          </div>

          <div className="mt-5 rounded-xl border border-slate-200 bg-slate-50 p-4">
            <p className="text-xs font-semibold text-slate-700">Sample Recommended Action</p>
            <p className="mt-1.5 text-sm leading-relaxed text-slate-700">
              {livePreview.recommendedAction}
            </p>
          </div>
        </aside>
      </div>
    </div>
  );
};
