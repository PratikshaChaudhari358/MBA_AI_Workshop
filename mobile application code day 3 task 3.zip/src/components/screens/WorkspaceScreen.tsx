import React, {useEffect, useState} from 'react';
import {
  Check,
  CheckSquare,
  Copy,
  Download,
  FileCode2,
  RefreshCw,
  ShieldCheck,
  Square,
} from 'lucide-react';
import QRCode from 'qrcode';
import {DOMAIN_CONFIGS} from '../../data/domains';
import type {
  BusinessDomainId,
  DeliverableItem,
  DomainConfig,
  EvaluatedRecord,
} from '../../types/business';
import {downloadAndroidStudioProject} from '../../utils/androidProjectExporter';
import {PWAInstallButton} from '../PWAInstallButton';

interface WorkspaceScreenProps {
  domain: DomainConfig;
  records: EvaluatedRecord[];
  checklist: DeliverableItem[];
  onChangeDomain: (id: BusinessDomainId) => void;
  onResetSampleData: () => void;
  onToggleChecklist: (id: string) => void;
}

type GuideTab = 'plan' | 'script' | 'viva';

export const WorkspaceScreen: React.FC<WorkspaceScreenProps> = ({
  domain,
  records,
  checklist,
  onChangeDomain,
  onResetSampleData,
  onToggleChecklist,
}) => {
  const [exportingApkZip, setExportingApkZip] = useState(false);
  const [exportMessage, setExportMessage] = useState<string | null>(null);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [guideTab, setGuideTab] = useState<GuideTab>('plan');

  const appUrl = typeof window !== 'undefined' ? window.location.origin : '';

  useEffect(() => {
    if (!appUrl) return;
    QRCode.toDataURL(appUrl, {
      width: 144,
      margin: 1,
      color: {dark: '#0F172A', light: '#FFFFFF'},
    })
      .then((url) => setQrDataUrl(url))
      .catch(() => setQrDataUrl(''));
  }, [appUrl]);

  const handleCopyUrl = async () => {
    if (!appUrl) return;
    try {
      await navigator.clipboard.writeText(appUrl);
      setCopiedUrl(true);
      setTimeout(() => setCopiedUrl(false), 2000);
    } catch {
      // Ignore clipboard failure
    }
  };

  const handleDownloadKotlinProject = async () => {
    setExportingApkZip(true);
    setExportMessage(null);
    try {
      await downloadAndroidStudioProject(domain, records);
      setExportMessage(
        'Downloaded VeridianOps_Task3_Pack ZIP containing the full Kotlin Jetpack Compose Android Studio project plus Functionality, Video Script, and Viva docs.'
      );
    } finally {
      setExportingApkZip(false);
    }
  };

  const handleExportJson = () => {
    const payload = {
      disclaimer: 'Synthetic sample data for academic demonstration only.',
      domain: domain.name,
      exportedAt: new Date().toISOString(),
      records,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], {type: 'application/json'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `veridian-ops-${domain.id}-sample-records.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const completedCount = checklist.filter((c) => c.completed).length;

  return (
    <div className="space-y-6">
      <div>
        <p className="text-xs text-slate-500">
          Mobile installation · Domain configuration · Native APK & docs export
        </p>
        <h1 className="mt-1 text-2xl font-bold tracking-tight text-slate-900">
          Workspace & Android Packaging
        </h1>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <section className="space-y-4 rounded-2xl border border-slate-200 bg-white p-6">
          <div>
            <h2 className="text-lg font-semibold text-slate-900">
              1. Install Directly on Android Mobile (PWA)
            </h2>
            <p className="mt-1 text-sm text-slate-600">
              Scan the QR code with your Android phone or open the Shared App URL in Chrome, then
              tap Install app to add Veridian Ops to your home screen.
            </p>
          </div>

          <div className="flex flex-col gap-4 rounded-xl border border-slate-200 bg-slate-50 p-4 sm:flex-row sm:items-center">
            {qrDataUrl ? (
              <img
                src={qrDataUrl}
                alt="QR code to open Veridian Ops on Android mobile"
                className="h-32 w-32 shrink-0 rounded-lg border border-slate-200 bg-white p-1"
              />
            ) : (
              <div className="flex h-32 w-32 shrink-0 items-center justify-center rounded-lg border border-slate-200 bg-white text-xs text-slate-400">
                QR ready
              </div>
            )}
            <div className="min-w-0 flex-1 space-y-2.5">
              <p className="text-xs font-medium text-slate-700">Mobile App URL</p>
              <p className="truncate rounded-lg border border-slate-200 bg-white px-2.5 py-2 font-mono text-xs text-slate-700">
                {appUrl}
              </p>
              <button
                type="button"
                onClick={handleCopyUrl}
                className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-800 hover:bg-slate-100"
              >
                {copiedUrl ? (
                  <>
                    <Check className="h-3.5 w-3.5 text-emerald-700" />
                    <span>Link Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="h-3.5 w-3.5" />
                    <span>Copy App Link</span>
                  </>
                )}
              </button>
            </div>
          </div>

          <PWAInstallButton variant="card" />

          <div className="border-t border-slate-100 pt-4">
            <h3 className="text-sm font-semibold text-slate-900">
              2. Export Native Android Studio Project + Task 3 Docs Pack
            </h3>
            <p className="mt-1 text-xs leading-relaxed text-slate-600">
              Downloads a complete 4-screen Kotlin + Jetpack Compose project aligned to{' '}
              <span className="font-medium text-slate-900">{domain.name}</span> to build your{' '}
              <span className="font-mono">.apk</span> in Android Studio, plus Functionality, Demo
              Script, and Viva Q&amp;A markdown files.
            </p>
            <button
              type="button"
              onClick={handleDownloadKotlinProject}
              disabled={exportingApkZip}
              className="mt-3 inline-flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl border border-slate-900 bg-slate-900 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-slate-800 disabled:opacity-60"
            >
              <FileCode2 className="h-4 w-4" />
              <span>
                {exportingApkZip
                  ? 'Packaging Android & Docs ZIP...'
                  : 'Download Android Studio + Docs Pack (.zip)'}
              </span>
            </button>
            {exportMessage && (
              <p className="mt-2.5 text-xs font-medium text-emerald-700">{exportMessage}</p>
            )}
          </div>
        </section>

        <section className="space-y-4 rounded-2xl border border-slate-200 bg-white p-6">
          <div>
            <h2 className="text-lg font-semibold text-slate-900">
              Business Domain Alignment (Tasks 1 &amp; 2)
            </h2>
            <p className="mt-1 text-sm text-slate-600">
              Switch the business domain to align all four screens, KPIs, synthetic records, and the
              exported Kotlin project with your chosen MBA problem statement.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            {(Object.keys(DOMAIN_CONFIGS) as BusinessDomainId[]).map((id) => {
              const cfg = DOMAIN_CONFIGS[id];
              const active = cfg.id === domain.id;
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => onChangeDomain(id)}
                  className={`min-h-[56px] rounded-xl border p-3.5 text-left transition-colors ${
                    active
                      ? 'border-blue-700 bg-blue-50/70 text-slate-900'
                      : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <p className="text-sm font-semibold">{cfg.shortLabel}</p>
                  <p className="mt-0.5 truncate text-xs text-slate-500">{cfg.name}</p>
                </button>
              );
            })}
          </div>

          <div className="flex flex-wrap gap-3 border-t border-slate-100 pt-4">
            <button
              type="button"
              onClick={onResetSampleData}
              className="inline-flex min-h-[44px] flex-1 items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap"
            >
              <RefreshCw className="h-3.5 w-3.5" />
              <span>Reset Synthetic Sample Data</span>
            </button>
            <button
              type="button"
              onClick={handleExportJson}
              className="inline-flex min-h-[44px] flex-1 items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Export Sample JSON</span>
            </button>
          </div>

          <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-sm font-semibold text-slate-900">Task 3 Reference Guide</h3>
              <div className="flex items-center gap-1 rounded-lg bg-slate-200/70 p-0.5">
                {(
                  [
                    {id: 'plan', label: 'Plan'},
                    {id: 'script', label: 'Video Script'},
                    {id: 'viva', label: 'Viva Q&A'},
                  ] as {id: GuideTab; label: string}[]
                ).map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => setGuideTab(t.id)}
                    className={`min-h-[32px] rounded-md px-2.5 text-xs font-medium transition-colors whitespace-nowrap ${
                      guideTab === t.id
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>
            </div>

            {guideTab === 'plan' && (
              <ol className="space-y-1.5 text-xs leading-relaxed text-slate-700">
                <li>1. Select your domain above to align all 4 screens to Tasks 1 &amp; 2.</li>
                <li>2. Install on Android Chrome via the QR code, or export the Kotlin ZIP.</li>
                <li>3. Open the ZIP in Android Studio and run Build &gt; Build APK(s).</li>
                <li>4. Capture 4 screenshots (Overview, Assess, Insights, Workspace).</li>
                <li>5. Record a 2–3 min screen walkthrough and submit with the docs pack.</li>
              </ol>
            )}

            {guideTab === 'script' && (
              <ol className="space-y-1.5 text-xs leading-relaxed text-slate-700">
                <li>0:00–0:30 · Overview: State {domain.shortLabel} problem &amp; KPI baseline.</li>
                <li>0:30–1:15 · Assess: Enter a synthetic scenario and show live buffer preview.</li>
                <li>1:15–2:00 · Insights: Show Sample Recommendations, filters, and resolve action.</li>
                <li>2:00–2:45 · Workspace: Highlight synthetic data labels and zero exposed keys.</li>
              </ol>
            )}

            {guideTab === 'viva' && (
              <ul className="space-y-1.5 text-xs leading-relaxed text-slate-700">
                <li>· Problem fit: Each screen directly supports {domain.name} decisions.</li>
                <li>· Sample labels: All projections are labelled Sample Model Output.</li>
                <li>· Security: Zero API keys, OAuth secrets, or real PII in client code or APK.</li>
              </ul>
            )}
          </div>
        </section>
      </div>

      <section className="rounded-2xl border border-slate-200 bg-white p-6">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="text-lg font-semibold text-slate-900">
              Task 3 Submission &amp; Viva Readiness Checklist
            </h2>
            <p className="text-xs text-slate-500">
              Track required deliverables before final packaging and viva demonstration.
            </p>
          </div>
          <span className="font-mono text-sm font-semibold text-slate-800 tabular-nums">
            {completedCount} / {checklist.length} ready
          </span>
        </div>

        <div className="mt-4 divide-y divide-slate-100">
          {checklist.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => onToggleChecklist(item.id)}
              className="flex min-h-[56px] w-full items-start gap-3 rounded-lg px-2 py-3 text-left transition-colors hover:bg-slate-50"
            >
              {item.completed ? (
                <CheckSquare className="mt-0.5 h-5 w-5 shrink-0 text-blue-700" />
              ) : (
                <Square className="mt-0.5 h-5 w-5 shrink-0 text-slate-400" />
              )}
              <div>
                <p
                  className={`text-sm font-medium ${
                    item.completed ? 'text-slate-500 line-through' : 'text-slate-900'
                  }`}
                >
                  {item.title}
                </p>
                <p className="mt-0.5 text-xs text-slate-500">{item.detail}</p>
              </div>
            </button>
          ))}
        </div>
      </section>

      <section className="flex items-start gap-3 rounded-2xl border border-slate-200 bg-slate-100/80 p-5">
        <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-slate-700" />
        <div className="text-xs leading-relaxed text-slate-700">
          <span className="font-semibold text-slate-900">Academic Integrity &amp; Security:</span>{' '}
          All records stored in this app are synthetic and anonymised. No API keys, OAuth client
          secrets, or personally identifiable customer data are stored in client code or exported
          bundles.
        </div>
      </section>
    </div>
  );
};
